import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  PageBreak,
  Table,
  TableRow,
  TableCell,
  WidthType,
  AlignmentType,
  VerticalAlign,
  BorderStyle,
  ShadingType,
  convertInchesToTwip,
  UnderlineType,
  SectionType,
  Footer,
  Header,
  PageNumber
} from 'docx'
import { saveAs } from 'file-saver'

// Tipos para o gerador de DOCX
interface ArtigoDOCX {
  id: number
  numero: number
  numeroTexto: string
  texto: string
  marcado: boolean
  cor: string | null
  nomeFromLei: string
  anotacao?: string
  tags?: string[]
  importancia?: number
  titulos?: { texto: string; posicao: number }[]
}

interface LeiDOCX {
  nome: string
  artigos: ArtigoDOCX[]
}

interface ConfigDOCX {
  titulo: string
  concurso: string
  autor: string
  codigo: string
  empresa: string
  edicao: string
  ano: string
  avisos: string
  comentarios: string
  tituloTransicao: string
  subtituloTransicao: string
  legendaCores: Record<string, string>
  formatacaoTitulosAtiva?: boolean
  delimitadorInicial?: string
  delimitadorFinal?: string
}

export class VademecumDOCXGenerator {
  private config: ConfigDOCX

  constructor() {
    this.config = {} as ConfigDOCX
  }

  private getCoresPaleta() {
    return {
      verde: '#22c55e',
      azul: '#3b82f6',
      amarelo: '#eab308',
      laranja: '#f97316',
      roxo: '#a855f7',
      cinza: '#6b7280'
    }
  }

  private createCapa(config: ConfigDOCX): Paragraph[] {
    const paragraphs: Paragraph[] = []

    // Espaço inicial
    paragraphs.push(new Paragraph({
      children: [new TextRun("")],
      spacing: { after: convertInchesToTwip(1) }
    }))

    // Título principal
    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: config.titulo,
          bold: true,
          size: 48,
          color: "2563eb"
        })
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: convertInchesToTwip(0.3) }
    }))

    // Subtítulo
    if (config.concurso) {
      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: config.concurso,
            size: 32,
            color: "4b5563"
          })
        ],
        alignment: AlignmentType.CENTER,
        spacing: { after: convertInchesToTwip(0.5) }
      }))
    }

    // Linha decorativa
    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: "___________________________________",
          color: "2563eb",
          bold: true
        })
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: convertInchesToTwip(0.5) }
    }))

    // Informações do documento
    if (config.autor) {
      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: `Autor: ${config.autor}`,
            size: 24
          })
        ],
        alignment: AlignmentType.CENTER,
        spacing: { after: convertInchesToTwip(0.1) }
      }))
    }

    if (config.empresa) {
      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: config.empresa,
            size: 24
          })
        ],
        alignment: AlignmentType.CENTER,
        spacing: { after: convertInchesToTwip(0.1) }
      }))
    }

    // Espaço para informações finais
    paragraphs.push(new Paragraph({
      children: [new TextRun("")],
      spacing: { after: convertInchesToTwip(2) }
    }))

    // Edição e ano
    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: `${config.edicao} - ${config.ano}`,
          size: 20,
          color: "6b7280"
        })
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: convertInchesToTwip(0.1) }
    }))

    if (config.codigo) {
      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: `Código: ${config.codigo}`,
            size: 16,
            color: "6b7280"
          })
        ],
        alignment: AlignmentType.CENTER
      }))
    }

    return paragraphs
  }

  private createLegendaCores(config: ConfigDOCX): Paragraph[] {
    const paragraphs: Paragraph[] = []
    const cores = this.getCoresPaleta()

    // Título da legenda
    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: "LEGENDA DE CORES",
          bold: true,
          size: 36,
          color: "2563eb"
        })
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: convertInchesToTwip(0.3) }
    }))

    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: "Este vademecum utiliza um sistema de cores para categorizar e destacar artigos importantes:",
          size: 20
        })
      ],
      spacing: { after: convertInchesToTwip(0.3) }
    }))

    // Criar tabela de cores
    const coreRows: TableRow[] = []

    for (const [key, corHex] of Object.entries(cores)) {
      if (config.legendaCores[key]) {
        const nomesCores = {
          verde: 'Verde',
          azul: 'Azul',
          amarelo: 'Amarelo',
          laranja: 'Laranja',
          roxo: 'Roxo',
          cinza: 'Cinza'
        }

        coreRows.push(new TableRow({
          children: [
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: "●",
                      color: corHex.replace('#', ''),
                      size: 32,
                      bold: true
                    })
                  ],
                  alignment: AlignmentType.CENTER
                })
              ],
              width: { size: 10, type: WidthType.PERCENTAGE },
              verticalAlign: VerticalAlign.CENTER
            }),
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: nomesCores[key as keyof typeof nomesCores],
                      bold: true,
                      size: 22
                    })
                  ]
                })
              ],
              width: { size: 20, type: WidthType.PERCENTAGE }
            }),
            new TableCell({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: config.legendaCores[key],
                      size: 20
                    })
                  ]
                })
              ],
              width: { size: 70, type: WidthType.PERCENTAGE }
            })
          ]
        }))
      }
    }

    if (coreRows.length > 0) {
      const tabelaCores = new Table({
        rows: coreRows,
        width: { size: 100, type: WidthType.PERCENTAGE },
        borders: {
          top: { style: BorderStyle.SINGLE, size: 1 },
          bottom: { style: BorderStyle.SINGLE, size: 1 },
          left: { style: BorderStyle.SINGLE, size: 1 },
          right: { style: BorderStyle.SINGLE, size: 1 },
          insideHorizontal: { style: BorderStyle.SINGLE, size: 1 },
          insideVertical: { style: BorderStyle.SINGLE, size: 1 }
        }
      })

      paragraphs.push(new Paragraph({
        children: [tabelaCores],
        spacing: { after: convertInchesToTwip(0.3) }
      }))
    }

    // Informações sobre formatação de títulos
    if (config.formatacaoTitulosAtiva) {
      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: "FORMATAÇÃO DE TÍTULOS",
            bold: true,
            size: 24,
            color: "7c3aed"
          })
        ],
        spacing: { before: convertInchesToTwip(0.3), after: convertInchesToTwip(0.1) }
      }))

      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: `Os títulos identificados pelos delimitadores "${config.delimitadorInicial}" e "${config.delimitadorFinal}" são formatados automaticamente com destaque especial.`,
            size: 18
          })
        ],
        spacing: { after: convertInchesToTwip(0.2) }
      }))
    }

    // Avisos
    if (config.avisos) {
      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: "AVISOS IMPORTANTES",
            bold: true,
            size: 24,
            color: "dc2626"
          })
        ],
        spacing: { before: convertInchesToTwip(0.3), after: convertInchesToTwip(0.1) }
      }))

      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: config.avisos,
            size: 18
          })
        ],
        spacing: { after: convertInchesToTwip(0.2) }
      }))
    }

    // Comentários
    if (config.comentarios) {
      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: "OBSERVAÇÕES",
            bold: true,
            size: 24,
            color: "2563eb"
          })
        ],
        spacing: { before: convertInchesToTwip(0.2), after: convertInchesToTwip(0.1) }
      }))

      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: config.comentarios,
            size: 18
          })
        ]
      }))
    }

    return paragraphs
  }

  private createSumario(leis: LeiDOCX[]): Paragraph[] {
    const paragraphs: Paragraph[] = []

    // Título do sumário
    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: "SUMÁRIO",
          bold: true,
          size: 36,
          color: "2563eb"
        })
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: convertInchesToTwip(0.3) }
    }))

    // Estatísticas
    const totalArtigos = leis.reduce((sum, lei) => sum + lei.artigos.length, 0)
    const artigosMarcados = leis.reduce((sum, lei) => sum + lei.artigos.filter(a => a.marcado).length, 0)
    const artigosComTitulos = leis.reduce((sum, lei) => sum + lei.artigos.filter(a => a.titulos && a.titulos.length > 0).length, 0)

    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: "📊 ESTATÍSTICAS",
          bold: true,
          size: 24,
          color: "2563eb"
        })
      ],
      spacing: { after: convertInchesToTwip(0.1) }
    }))

    const estatisticas = [
      `• Total de leis: ${leis.length}`,
      `• Total de artigos: ${totalArtigos}`,
      `• Artigos marcados: ${artigosMarcados}`,
      `• Artigos com títulos: ${artigosComTitulos}`,
      `• Porcentagem marcada: ${totalArtigos > 0 ? Math.round((artigosMarcados / totalArtigos) * 100) : 0}%`
    ]

    for (const stat of estatisticas) {
      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: stat,
            size: 20
          })
        ],
        spacing: { after: convertInchesToTwip(0.05) }
      }))
    }

    // Lista de leis
    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: "📚 LEIS INCLUÍDAS",
          bold: true,
          size: 24,
          color: "2563eb"
        })
      ],
      spacing: { before: convertInchesToTwip(0.3), after: convertInchesToTwip(0.1) }
    }))

    leis.forEach((lei, index) => {
      const marcados = lei.artigos.filter(a => a.marcado).length
      const comTitulos = lei.artigos.filter(a => a.titulos && a.titulos.length > 0).length

      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: `${index + 1}. ${lei.nome}`,
            bold: true,
            size: 20
          })
        ],
        spacing: { after: convertInchesToTwip(0.02) }
      }))

      paragraphs.push(new Paragraph({
        children: [
          new TextRun({
            text: `   ${lei.artigos.length} artigos (${marcados} marcados, ${comTitulos} com títulos)`,
            size: 18,
            color: "6b7280"
          })
        ],
        spacing: { after: convertInchesToTwip(0.08) }
      }))
    })

    return paragraphs
  }

  private createPaginaTransicao(config: ConfigDOCX): Paragraph[] {
    const paragraphs: Paragraph[] = []

    // Espaço para centralizar verticalmente
    paragraphs.push(new Paragraph({
      children: [new TextRun("")],
      spacing: { after: convertInchesToTwip(3) }
    }))

    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: config.tituloTransicao,
          bold: true,
          size: 56,
          color: "2563eb"
        })
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: convertInchesToTwip(0.3) }
    }))

    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: config.subtituloTransicao,
          size: 28,
          color: "6b7280"
        })
      ],
      alignment: AlignmentType.CENTER,
      spacing: { after: convertInchesToTwip(0.5) }
    }))

    // Linha decorativa
    paragraphs.push(new Paragraph({
      children: [
        new TextRun({
          text: "___________________________________",
          color: "2563eb",
          bold: true
        })
      ],
      alignment: AlignmentType.CENTER
    }))

    return paragraphs
  }

  private createConteudo(leis: LeiDOCX[]): Paragraph[] {
    const paragraphs: Paragraph[] = []
    const cores = this.getCoresPaleta()

    // Ordenar artigos por lei e depois por número
    const todosArtigos = leis.flatMap(lei =>
      lei.artigos.map(artigo => ({
        ...artigo,
        nomeLei: lei.nome
      }))
    ).sort((a, b) => {
      const leiCompare = a.nomeLei.localeCompare(b.nomeLei)
      if (leiCompare !== 0) return leiCompare
      return a.numero - b.numero
    })

    let leiAtual = ''

    for (const artigo of todosArtigos) {
      // Nova seção por lei
      if (artigo.nomeLei !== leiAtual) {
        if (leiAtual !== '') {
          // Espaço entre leis
          paragraphs.push(new Paragraph({
            children: [new TextRun("")],
            spacing: { after: convertInchesToTwip(0.2) }
          }))
        }

        leiAtual = artigo.nomeLei

        // Título da lei
        paragraphs.push(new Paragraph({
          children: [
            new TextRun({
              text: leiAtual,
              bold: true,
              size: 22,
              color: "ffffff"
            })
          ],
          alignment: AlignmentType.LEFT,
          spacing: { after: convertInchesToTwip(0.15) },
          shading: {
            type: ShadingType.SOLID,
            color: "2563eb"
          }
        }))
      }

      // Criar parágrafo para o artigo
      const artigoChildren: TextRun[] = []

      // Número do artigo
      artigoChildren.push(new TextRun({
        text: `Art. ${artigo.numeroTexto || artigo.numero} `,
        bold: true,
        size: 20,
        color: "2563eb"
      }))

      // Indicador de cor se marcado
      if (artigo.marcado && artigo.cor) {
        const corHex = cores[artigo.cor as keyof typeof cores]
        if (corHex) {
          artigoChildren.push(new TextRun({
            text: "● ",
            color: corHex.replace('#', ''),
            size: 20,
            bold: true
          }))
        }
      }

      // Texto do artigo
      artigoChildren.push(new TextRun({
        text: artigo.texto,
        size: 18
      }))

      // Verificar se tem fundo colorido
      let artigoParagraph: Paragraph
      if (artigo.marcado && artigo.cor) {
        const coresFundo = {
          verde: "dcfce7",
          azul: "dbeafe",
          amarelo: "fef3c7",
          laranja: "fed7aa",
          roxo: "f3e8ff",
          cinza: "f3f4f6"
        }
        const corFundo = coresFundo[artigo.cor as keyof typeof coresFundo]

        artigoParagraph = new Paragraph({
          children: artigoChildren,
          spacing: { after: convertInchesToTwip(0.1) },
          shading: corFundo ? {
            type: ShadingType.SOLID,
            color: corFundo
          } : undefined
        })
      } else {
        artigoParagraph = new Paragraph({
          children: artigoChildren,
          spacing: { after: convertInchesToTwip(0.1) }
        })
      }

      paragraphs.push(artigoParagraph)

      // Adicionar títulos se existirem
      if (artigo.titulos && artigo.titulos.length > 0) {
        for (const titulo of artigo.titulos) {
          paragraphs.push(new Paragraph({
            children: [
              new TextRun({
                text: `📋 Título: ${titulo.texto}`,
                bold: true,
                size: 16,
                color: "7c3aed",
                underline: {
                  type: UnderlineType.SINGLE,
                  color: "7c3aed"
                }
              })
            ],
            spacing: { after: convertInchesToTwip(0.05) },
            shading: {
              type: ShadingType.SOLID,
              color: "f3e8ff"
            }
          }))
        }
      }

      // Adicionar anotação se existir
      if (artigo.anotacao?.trim()) {
        paragraphs.push(new Paragraph({
          children: [
            new TextRun({
              text: "📝 Anotação: ",
              bold: true,
              size: 16,
              color: "059669"
            }),
            new TextRun({
              text: artigo.anotacao,
              size: 16,
              italics: true,
              color: "059669"
            })
          ],
          spacing: { after: convertInchesToTwip(0.05) }
        }))
      }

      // Adicionar tags se existirem
      if (artigo.tags && artigo.tags.length > 0) {
        paragraphs.push(new Paragraph({
          children: [
            new TextRun({
              text: "🏷️ Tags: ",
              bold: true,
              size: 16,
              color: "7c3aed"
            }),
            new TextRun({
              text: artigo.tags.join(', '),
              size: 16,
              color: "7c3aed"
            })
          ],
          spacing: { after: convertInchesToTwip(0.05) }
        }))
      }

      // Adicionar importância se definida
      if (artigo.importancia && artigo.importancia > 0) {
        const estrelas = '⭐'.repeat(artigo.importancia)
        paragraphs.push(new Paragraph({
          children: [
            new TextRun({
              text: `Importância: ${estrelas} (${artigo.importancia}/5)`,
              bold: true,
              size: 16,
              color: "ea580c"
            })
          ],
          spacing: { after: convertInchesToTwip(0.1) }
        }))
      }

      // Espaço entre artigos
      paragraphs.push(new Paragraph({
        children: [new TextRun("")],
        spacing: { after: convertInchesToTwip(0.1) }
      }))
    }

    return paragraphs
  }

  async gerarDOCX(leis: LeiDOCX[], config: ConfigDOCX) {
    try {
      this.config = config

      const sections = []

      // 1. Capa
      sections.push({
        properties: {
          page: {
            margin: {
              top: convertInchesToTwip(1),
              bottom: convertInchesToTwip(1),
              left: convertInchesToTwip(1),
              right: convertInchesToTwip(1)
            }
          }
        },
        children: [
          ...this.createCapa(config),
          new Paragraph({
            children: [new PageBreak()]
          })
        ]
      })

      // 2. Legenda de cores
      sections.push({
        properties: {
          page: {
            margin: {
              top: convertInchesToTwip(1),
              bottom: convertInchesToTwip(1),
              left: convertInchesToTwip(1),
              right: convertInchesToTwip(1)
            }
          }
        },
        children: [
          ...this.createLegendaCores(config),
          new Paragraph({
            children: [new PageBreak()]
          })
        ]
      })

      // 3. Sumário
      sections.push({
        properties: {
          page: {
            margin: {
              top: convertInchesToTwip(1),
              bottom: convertInchesToTwip(1),
              left: convertInchesToTwip(1),
              right: convertInchesToTwip(1)
            }
          }
        },
        children: [
          ...this.createSumario(leis),
          new Paragraph({
            children: [new PageBreak()]
          })
        ]
      })

      // 4. Página de transição
      sections.push({
        properties: {
          page: {
            margin: {
              top: convertInchesToTwip(1),
              bottom: convertInchesToTwip(1),
              left: convertInchesToTwip(1),
              right: convertInchesToTwip(1)
            }
          }
        },
        children: [
          ...this.createPaginaTransicao(config),
          new Paragraph({
            children: [new PageBreak()]
          })
        ]
      })

      // 5. Conteúdo principal
      sections.push({
        properties: {
          page: {
            margin: {
              top: convertInchesToTwip(1),
              bottom: convertInchesToTwip(1),
              left: convertInchesToTwip(1),
              right: convertInchesToTwip(1)
            }
          },
          headers: {
            default: new Header({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: config.titulo,
                      size: 16,
                      color: "6b7280"
                    })
                  ],
                  alignment: AlignmentType.CENTER
                })
              ]
            })
          },
          footers: {
            default: new Footer({
              children: [
                new Paragraph({
                  children: [
                    new TextRun({
                      text: "Página ",
                      size: 16,
                      color: "6b7280"
                    }),
                    new TextRun({
                      children: [PageNumber.CURRENT],
                      size: 16,
                      color: "6b7280"
                    })
                  ],
                  alignment: AlignmentType.CENTER
                })
              ]
            })
          }
        },
        children: this.createConteudo(leis)
      })

      // Criar o documento
      const doc = new Document({
        title: config.titulo,
        creator: config.autor,
        description: `Vademecum gerado em ${new Date().toLocaleDateString('pt-BR')} ${config.formatacaoTitulosAtiva ? 'com títulos formatados' : ''}`,
        sections
      })

      // Gerar e baixar o arquivo
      const buffer = await Packer.toBuffer(doc)
      const blob = new Blob([buffer], {
        type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
      })

      saveAs(blob, `${config.titulo.replace(/[^a-zA-Z0-9]/g, '_')}.docx`)

      return true
    } catch (error) {
      console.error('Erro ao gerar DOCX:', error)
      throw error
    }
  }
}
