import { useState, useEffect, useCallback } from 'react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './components/ui/tabs'
import { Button } from './components/ui/button'
import { Input } from './components/ui/input'
import { Textarea } from './components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './components/ui/card'
import { Badge } from './components/ui/badge'
import { Alert, AlertDescription } from './components/ui/alert'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './components/ui/select'
import {
  Upload,
  Edit,
  Palette,
  Eye,
  Download,
  Plus,
  FileText,
  CheckCircle,
  AlertCircle,
  Loader2,
  Search,
  X,
  Filter
} from 'lucide-react'
import { VademecumPDFGenerator } from './lib/pdfGenerator'
import { VademecumDOCXGenerator } from './lib/docxGenerator'

// Tipos TypeScript
interface Artigo {
  id: number
  numero: number
  numeroTexto: string
  texto: string
  marcado: boolean
  cor: string | null
  tipo: 'artigo'
  anotacoes: string
  tags: string[]
  importancia: 1 | 2 | 3 | 4 | 5
  dataUltimaEdicao: string
}

interface Lei {
  id: number
  nome: string
  textoCompleto: string
  artigos: Artigo[]
}

interface Vademecum {
  leis: Lei[]
  legendaCores: Record<string, string>
}

interface Message {
  type: 'success' | 'error'
  text: string
}

// Cores disponíveis
const CORES = {
  verde: { bg: 'bg-green-500', text: 'text-green-500', label: 'Verde' },
  azul: { bg: 'bg-blue-500', text: 'text-blue-500', label: 'Azul' },
  amarelo: { bg: 'bg-yellow-500', text: 'text-yellow-500', label: 'Amarelo' },
  laranja: { bg: 'bg-orange-500', text: 'text-orange-500', label: 'Laranja' },
  roxo: { bg: 'bg-purple-500', text: 'text-purple-500', label: 'Roxo' },
  cinza: { bg: 'bg-gray-500', text: 'text-gray-500', label: 'Cinza' }
}

function App() {
  // Estados principais
  const [vademecum, setVademecum] = useState<Vademecum>({
    leis: [],
    legendaCores: {
      verde: 'Artigos mais cobrados',
      azul: 'Jurisprudência relevante',
      amarelo: 'Alterações recentes',
      laranja: 'Doutrina importante',
      roxo: 'Súmulas vinculantes',
      cinza: 'Observações gerais'
    }
  })

  const [leiSelecionada, setLeiSelecionada] = useState<number | null>(null)
  const [artigoSelecionado, setArtigoSelecionado] = useState<number | null>(null)
  const [message, setMessage] = useState<Message | null>(null)
  const [gerandoPDF, setGerandoPDF] = useState(false)
  const [gerandoDOCX, setGerandoDOCX] = useState(false)

  // Estados de busca
  const [termoBusca, setTermoBusca] = useState('')
  const [filtroLei, setFiltroLei] = useState<number | null>(null)
  const [filtroCor, setFiltroCor] = useState<string | null>(null)
  const [filtroMarcados, setFiltroMarcados] = useState<'todos' | 'marcados' | 'nao-marcados'>('todos')
  const [tipoOrdenacao, setTipoOrdenacao] = useState<'relevancia' | 'numero' | 'lei'>('relevancia')
  const [resultadosBusca, setResultadosBusca] = useState<Array<{
    lei: Lei,
    artigo: Artigo,
    destaque: string,
    score: number
  }>>([])
  const [historicoBusca, setHistoricoBusca] = useState<string[]>([])
  const [buscaAvancada, setBuscaAvancada] = useState(false)

  // Estados do formulário
  const [nomeNovaLei, setNomeNovaLei] = useState('')
  const [textoNovaLei, setTextoNovaLei] = useState('')
  const [tituloVademecum, setTituloVademecum] = useState('Vademecum Estatístico')
  const [nomeConcurso, setNomeConcurso] = useState('')
  const [autorVademecum, setAutorVademecum] = useState('')
  const [codigoVademecum, setCodigoVademecum] = useState('')
  const [nomeEmpresa, setNomeEmpresa] = useState('')
  const [avisosVademecum, setAvisosVademecum] = useState('')
  const [comentariosVademecum, setComentariosVademecum] = useState('')
  const [edicaoVademecum, setEdicaoVademecum] = useState('1ª Edição')
  const [anoVademecum, setAnoVademecum] = useState(new Date().getFullYear().toString())
  const [tituloTransicao, setTituloTransicao] = useState('LEGISLAÇÃO')
  const [subtituloTransicao, setSubtituloTransicao] = useState('Compilação de Artigos por Lei')

  // Estados para edição e cores flutuantes
  const [textoEditavel, setTextoEditavel] = useState('')
  const [mostrarCoresFlutantes, setMostrarCoresFlutantes] = useState(false)
  const [posicaoCores, setPosicaoCores] = useState({ x: 0, y: 0 })

  // Estados para sistema de títulos
  const [formatacaoTitulosAtiva, setFormatacaoTitulosAtiva] = useState(true)
  const [delimitadorInicial, setDelimitadorInicial] = useState('*(')
  const [delimitadorFinal, setDelimitadorFinal] = useState(')*')
  const [mostrarConfigTitulos, setMostrarConfigTitulos] = useState(false)

  // Carregar dados do localStorage
  useEffect(() => {
    const dadosSalvos = localStorage.getItem('vademecum-data')
    if (dadosSalvos) {
      try {
        setVademecum(JSON.parse(dadosSalvos))
      } catch (error) {
        console.error('Erro ao carregar dados salvos:', error)
      }
    }
  }, [])

  // Salvar dados no localStorage
  useEffect(() => {
    localStorage.setItem('vademecum-data', JSON.stringify(vademecum))
  }, [vademecum])

  // Função para mostrar mensagens
  const showMessage = (type: 'success' | 'error', text: string) => {
    setMessage({ type, text })
    setTimeout(() => setMessage(null), 3000)
  }

  // Função para processar artigos de uma lei
  const processarArtigos = (texto: string): Artigo[] => {
    const linhas = texto.split('\n').filter(linha => linha.trim())
    const artigos: Artigo[] = []
    let artigoAtual: Artigo | null = null

    for (const linha of linhas) {
      const linhaTrimmed = linha.trim()
      if (!linhaTrimmed) continue

      // Detectar início de artigo
      const matchArtigo = linhaTrimmed.match(/^Art\.?\s*(\d+)[ºª°]?[\s\-–—\.]/i)

      if (matchArtigo) {
        // Salvar artigo anterior se existir
        if (artigoAtual) {
          artigos.push(artigoAtual)
        }

        // Iniciar novo artigo
        artigoAtual = {
          id: Date.now() + Math.random() * 1000000,
          numero: Number.parseInt(matchArtigo[1]),
          numeroTexto: matchArtigo[1],
          texto: linhaTrimmed,
          marcado: false,
          cor: null,
          tipo: 'artigo',
          anotacoes: '',
          tags: [],
          importancia: 1,
          dataUltimaEdicao: new Date().toISOString()
        }
      } else if (artigoAtual) {
        // Adicionar linha ao artigo atual
        artigoAtual.texto += `\n${linhaTrimmed}`
      }
    }

    // Adicionar último artigo se existir
    if (artigoAtual) {
      artigos.push(artigoAtual)
    }

    // Ordenar artigos por número
    artigos.sort((a, b) => a.numero - b.numero)
    return artigos
  }

  // Função para detectar títulos
  const detectarTitulos = useCallback((texto: string) => {
    if (!formatacaoTitulosAtiva) return null

    try {
      const escapedInicial = delimitadorInicial.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      const escapedFinal = delimitadorFinal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      const regexPattern = `${escapedInicial}(.*?)${escapedFinal}`
      const regexTitulo = new RegExp(regexPattern, 'g')

      const titulos: { texto: string; posicao: number }[] = []
      let match: RegExpExecArray | null = null

      match = regexTitulo.exec(texto)
      while (match !== null) {
        titulos.push({
          texto: match[1].trim(),
          posicao: match.index
        })
        match = regexTitulo.exec(texto)
      }

      return titulos.length > 0 ? titulos : null
    } catch {
      return null
    }
  }, [formatacaoTitulosAtiva, delimitadorInicial, delimitadorFinal])

  // Função para renderizar texto com títulos formatados
  const renderTextoComTitulos = useCallback((texto: string) => {
    if (!formatacaoTitulosAtiva) {
      return <span className="whitespace-pre-line">{texto}</span>
    }

    try {
      const escapedInicial = delimitadorInicial.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      const escapedFinal = delimitadorFinal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      const regexPattern = `${escapedInicial}(.*?)${escapedFinal}`
      const regexTitulo = new RegExp(regexPattern, 'g')

      const partes = texto.split(regexTitulo)
      const elementos: JSX.Element[] = []

      for (let i = 0; i < partes.length; i++) {
        if (i % 2 === 0) {
          // Texto normal
          if (partes[i]) {
            elementos.push(
              <span key={`texto-${i}`} className="whitespace-pre-line">
                {partes[i]}
              </span>
            )
          }
        } else {
          // Título formatado
          elementos.push(
            <div key={`titulo-${i}`} className="my-4">
              <div className="font-black text-xl leading-tight text-blue-800 bg-blue-50 px-4 py-3 rounded-lg border-l-4 border-blue-600 shadow-sm">
                {partes[i].trim()}
              </div>
            </div>
          )
        }
      }

      return <div>{elementos}</div>
    } catch {
      return <span className="whitespace-pre-line">{texto}</span>
    }
  }, [formatacaoTitulosAtiva, delimitadorInicial, delimitadorFinal])

  // Função de busca
  const realizarBusca = useCallback((termo: string) => {
    if (!termo.trim()) {
      setResultadosBusca([])
      return
    }

    const termoLimpo = termo.toLowerCase().trim()
    const resultados: Array<{
      lei: Lei,
      artigo: Artigo,
      destaque: string,
      score: number
    }> = []

    // Adicionar ao histórico
    setHistoricoBusca(prev => {
      const novoHistorico = [termo, ...prev.filter(h => h !== termo)].slice(0, 5)
      return novoHistorico
    })

    for (const lei of vademecum.leis) {
      // Filtro por lei específica
      if (filtroLei && lei.id !== filtroLei) continue

      for (const artigo of lei.artigos) {
        // Filtros de status
        if (filtroMarcados === 'marcados' && !artigo.marcado) continue
        if (filtroMarcados === 'nao-marcados' && artigo.marcado) continue
        if (filtroCor && artigo.cor !== filtroCor) continue

        let score = 0
        let destaque = artigo.texto

        // Busca por número do artigo (alta prioridade)
        const numeroStr = artigo.numero.toString()
        if (numeroStr === termoLimpo || artigo.numeroTexto === termoLimpo) {
          score += 100
          destaque = destaque.replace(
            new RegExp(`(Art\\.?\\s*${numeroStr}[ºª°]?)`, 'gi'),
            '<mark class="bg-yellow-200 font-bold">$1</mark>'
          )
        } else if (numeroStr.includes(termoLimpo)) {
          score += 80
        }

        // Busca no texto do artigo
        const textoLimpo = artigo.texto.toLowerCase()
        if (textoLimpo.includes(termoLimpo)) {
          score += 50

          // Destacar o termo encontrado
          const regex = new RegExp(`(${termoLimpo.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')})`, 'gi')
          destaque = destaque.replace(regex, '<mark class="bg-yellow-200 font-bold">$1</mark>')
        }

        // Busca em títulos
        if (formatacaoTitulosAtiva) {
          const titulos = detectarTitulos(artigo.texto)
          if (titulos) {
            for (const titulo of titulos) {
              if (titulo.texto.toLowerCase().includes(termoLimpo)) {
                score += 70 // Bonus para títulos
              }
            }
          }
        }

        // Bonus para artigos marcados
        if (artigo.marcado) {
          score += 10
        }

        if (score > 0) {
          // Limitar o destaque para melhor visualização
          if (destaque.length > 200) {
            const match = destaque.match(/<mark[^>]*>.*?<\/mark>/i)
            if (match) {
              const inicio = Math.max(0, destaque.indexOf(match[0]) - 50)
              const fim = Math.min(destaque.length, destaque.indexOf(match[0]) + match[0].length + 50)
              destaque = (inicio > 0 ? '...' : '') + destaque.substring(inicio, fim) + (fim < destaque.length ? '...' : '')
            } else {
              destaque = `${destaque.substring(0, 200)}...`
            }
          }

          resultados.push({
            lei,
            artigo,
            destaque,
            score
          })
        }
      }
    }

    setResultadosBusca(resultados)
  }, [vademecum.leis, filtroLei, filtroMarcados, filtroCor, detectarTitulos, formatacaoTitulosAtiva])

  // Função para adicionar lei
  const adicionarLei = () => {
    if (!nomeNovaLei.trim() || !textoNovaLei.trim()) {
      showMessage('error', 'Por favor, preencha o nome e o texto da lei')
      return
    }

    const artigos = processarArtigos(textoNovaLei)

    if (artigos.length === 0) {
      showMessage('error', 'Nenhum artigo foi encontrado no texto')
      return
    }

    const novaLei: Lei = {
      id: Date.now(),
      nome: nomeNovaLei,
      textoCompleto: textoNovaLei,
      artigos: artigos
    }

    setVademecum(prev => ({
      ...prev,
      leis: [...prev.leis, novaLei]
    }))

    // Limpar formulário
    setNomeNovaLei('')
    setTextoNovaLei('')

    showMessage('success', `Lei "${nomeNovaLei}" adicionada com ${artigos.length} artigos`)
  }

  // Função para carregar exemplo
  const carregarExemplo = () => {
    const exemploLei: Lei = {
      id: Date.now(),
      nome: "Código de Defesa do Consumidor - Lei nº 8.078/1990",
      textoCompleto: `Art. 1° O presente código estabelece normas de proteção e defesa do consumidor.

*(Capítulo I - Disposições Gerais)*

Art. 2° Consumidor é toda pessoa física ou jurídica que adquire ou utiliza produto ou serviço como destinatário final.

*(Das Definições)*

Art. 3° Fornecedor é toda pessoa física ou jurídica que desenvolvem atividade de produção, montagem, criação, construção, transformação, importação, exportação, distribuição ou comercialização de produtos ou prestação de serviços.

*(Seção II - Da Política Nacional)*

Art. 4° A Política Nacional das Relações de Consumo tem por objetivo o atendimento das necessidades dos consumidores, o respeito à sua dignidade, saúde e segurança, a proteção de seus interesses econômicos, a melhoria da sua qualidade de vida.`,
      artigos: []
    }

    // Processar artigos
    const artigos = processarArtigos(exemploLei.textoCompleto)
    exemploLei.artigos = artigos

    setVademecum(prev => ({
      ...prev,
      leis: [...prev.leis, exemploLei]
    }))

    showMessage('success', `Exemplo do CDC carregado com ${artigos.length} artigos`)
  }

  // Função para marcar artigo
  const marcarArtigo = (cor: string) => {
    if (!leiSelecionada || !artigoSelecionado) {
      showMessage('error', 'Selecione uma lei e um artigo primeiro')
      return
    }

    setVademecum(prev => ({
      ...prev,
      leis: prev.leis.map(lei =>
        lei.id === leiSelecionada
          ? {
              ...lei,
              artigos: lei.artigos.map(artigo =>
                artigo.id === artigoSelecionado
                  ? { ...artigo, marcado: true, cor, texto: textoEditavel || artigo.texto }
                  : artigo
              )
            }
          : lei
      )
    }))

    setMostrarCoresFlutantes(false)
    showMessage('success', `Artigo marcado com a cor ${CORES[cor as keyof typeof CORES]?.label || cor}`)
  }

  // Função para mostrar paleta de cores
  const mostrarPaletaCores = (event: React.MouseEvent) => {
    if (!artigoSelecionado) return

    const rect = event.currentTarget.getBoundingClientRect()
    setPosicaoCores({
      x: rect.right + 10,
      y: rect.top
    })
    setMostrarCoresFlutantes(true)
  }

  // Função para salvar texto editado
  const salvarTextoEditado = () => {
    if (!leiSelecionada || !artigoSelecionado) return

    setVademecum(prev => ({
      ...prev,
      leis: prev.leis.map(lei =>
        lei.id === leiSelecionada
          ? {
              ...lei,
              artigos: lei.artigos.map(artigo =>
                artigo.id === artigoSelecionado
                  ? { ...artigo, texto: textoEditavel }
                  : artigo
              )
            }
          : lei
      )
    }))

    showMessage('success', 'Texto do artigo atualizado')
  }

  // Funções de exportação
  const gerarPDF = async () => {
    try {
      setGerandoPDF(true)

      const pdfGenerator = new VademecumPDFGenerator()

      // Preparar dados para o PDF
      const leisPDF = vademecum.leis.map(lei => ({
        nome: lei.nome,
        artigos: lei.artigos.map(artigo => ({
          ...artigo,
          nomeFromLei: lei.nome,
          titulos: formatacaoTitulosAtiva ? detectarTitulos(artigo.texto) || undefined : undefined
        }))
      }))

      const configPDF = {
        titulo: tituloVademecum,
        concurso: nomeConcurso,
        autor: autorVademecum,
        codigo: codigoVademecum,
        empresa: nomeEmpresa,
        edicao: edicaoVademecum,
        ano: anoVademecum,
        avisos: avisosVademecum,
        comentarios: comentariosVademecum,
        tituloTransicao: tituloTransicao,
        subtituloTransicao: subtituloTransicao,
        legendaCores: vademecum.legendaCores
      }

      await pdfGenerator.gerarPDF(leisPDF, configPDF)
      showMessage('success', 'PDF gerado com sucesso!')

    } catch (error) {
      console.error('Erro ao gerar PDF:', error)
      showMessage('error', 'Erro ao gerar PDF. Tente novamente.')
    } finally {
      setGerandoPDF(false)
    }
  }

  const gerarDOCX = async () => {
    try {
      setGerandoDOCX(true)

      const docxGenerator = new VademecumDOCXGenerator()

      // Preparar dados para o DOCX
      const leisDOCX = vademecum.leis.map(lei => ({
        nome: lei.nome,
        artigos: lei.artigos.map(artigo => ({
          ...artigo,
          nomeFromLei: lei.nome,
          titulos: formatacaoTitulosAtiva ? detectarTitulos(artigo.texto) || undefined : undefined
        }))
      }))

      const configDOCX = {
        titulo: tituloVademecum,
        concurso: nomeConcurso,
        autor: autorVademecum,
        codigo: codigoVademecum,
        empresa: nomeEmpresa,
        edicao: edicaoVademecum,
        ano: anoVademecum,
        avisos: avisosVademecum,
        comentarios: comentariosVademecum,
        tituloTransicao: tituloTransicao,
        subtituloTransicao: subtituloTransicao,
        legendaCores: vademecum.legendaCores,
        formatacaoTitulosAtiva: formatacaoTitulosAtiva,
        delimitadorInicial: delimitadorInicial,
        delimitadorFinal: delimitadorFinal
      }

      await docxGenerator.gerarDOCX(leisDOCX, configDOCX)
      showMessage('success', 'DOCX gerado com sucesso!')

    } catch (error) {
      console.error('Erro ao gerar DOCX:', error)
      showMessage('error', 'Erro ao gerar DOCX. Tente novamente.')
    } finally {
      setGerandoDOCX(false)
    }
  }

  // Calcular estatísticas
  const stats = {
    totalLeis: vademecum.leis.length,
    totalArtigos: vademecum.leis.reduce((sum, lei) => sum + lei.artigos.length, 0),
    totalMarcados: vademecum.leis.reduce((sum, lei) =>
      sum + lei.artigos.filter(a => a.marcado).length, 0),
    coresUsadas: new Set(
      vademecum.leis.flatMap(lei =>
        lei.artigos.filter(a => a.marcado).map(a => a.cor)
      )
    ).size
  }

  const leiAtual = vademecum.leis.find(lei => lei.id === leiSelecionada)
  const artigoAtual = leiAtual?.artigos.find(a => a.id === artigoSelecionado)

  // Sincronizar texto editável quando artigo for selecionado
  useEffect(() => {
    if (artigoAtual) {
      setTextoEditavel(artigoAtual.texto)
    } else {
      setTextoEditavel('')
    }
  }, [artigoAtual])

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 py-8">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">Vademecum Estatístico</h1>
          <p className="text-gray-600">Editor profissional de leis com marcação colorida e sistema de títulos</p>
        </div>

        {/* Mensagem de Status */}
        {message && (
          <Alert className={`mb-4 ${message.type === 'success' ? 'border-green-500' : 'border-red-500'}`}>
            {message.type === 'success' ? (
              <CheckCircle className="h-4 w-4 text-green-500" />
            ) : (
              <AlertCircle className="h-4 w-4 text-red-500" />
            )}
            <AlertDescription className={message.type === 'success' ? 'text-green-700' : 'text-red-700'}>
              {message.text}
            </AlertDescription>
          </Alert>
        )}

        {/* Tabs Principal */}
        <Card className="shadow-lg">
          <Tabs defaultValue="import" className="w-full">
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="import">
                <Upload className="w-4 h-4 mr-2" />
                Importar
              </TabsTrigger>
              <TabsTrigger value="edit">
                <Edit className="w-4 h-4 mr-2" />
                Editar
              </TabsTrigger>
              <TabsTrigger value="search">
                <Search className="w-4 h-4 mr-2" />
                Buscar
              </TabsTrigger>
              <TabsTrigger value="colors">
                <Palette className="w-4 h-4 mr-2" />
                Cores
              </TabsTrigger>
              <TabsTrigger value="preview">
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </TabsTrigger>
              <TabsTrigger value="export">
                <Download className="w-4 h-4 mr-2" />
                Exportar
              </TabsTrigger>
            </TabsList>

            {/* Tab Import */}
            <TabsContent value="import">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <FileText className="w-5 h-5" />
                  Importar Nova Lei
                </CardTitle>
                <CardDescription>
                  Adicione uma nova lei ao seu vademecum. Cole o texto completo da lei. Use *(título)* para marcar títulos.
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">Nome da Lei</label>
                  <Input
                    placeholder="Ex: Constituição Federal, Código Penal..."
                    value={nomeNovaLei}
                    onChange={(e) => setNomeNovaLei(e.target.value)}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium mb-2">Texto da Lei</label>
                  <Textarea
                    rows={10}
                    placeholder="Cole aqui o texto completo da lei... Use *(título)* para marcar títulos."
                    value={textoNovaLei}
                    onChange={(e) => setTextoNovaLei(e.target.value)}
                  />
                </div>

                {/* Configuração de Títulos */}
                <div className="border rounded-lg p-4 bg-blue-50">
                  <div className="flex items-center justify-between mb-2">
                    <div className="text-sm font-medium text-blue-800">Sistema de Títulos</div>
                    <div className="flex items-center gap-2">
                      <span className="text-xs text-blue-600">
                        {formatacaoTitulosAtiva ? 'Ativo' : 'Inativo'}
                      </span>
                      <button
                        onClick={() => setFormatacaoTitulosAtiva(!formatacaoTitulosAtiva)}
                        className={`w-8 h-4 rounded-full transition-colors ${
                          formatacaoTitulosAtiva ? 'bg-blue-600' : 'bg-gray-300'
                        }`}
                      >
                        <div className={`w-3 h-3 bg-white rounded-full transition-transform ${
                          formatacaoTitulosAtiva ? 'translate-x-4' : 'translate-x-0'
                        }`} />
                      </button>
                    </div>
                  </div>
                  {formatacaoTitulosAtiva && (
                    <div className="text-xs text-blue-600">
                      <strong>Exemplo:</strong> {delimitadorInicial}Capítulo I{delimitadorFinal} será formatado como título em negrito e destaque.
                    </div>
                  )}
                </div>

                <div className="flex gap-3">
                  <Button onClick={adicionarLei} className="flex items-center gap-2">
                    <Plus className="w-4 h-4" />
                    Adicionar Lei
                  </Button>
                  <Button
                    onClick={carregarExemplo}
                    variant="outline"
                    className="flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4" />
                    Carregar Exemplo (CDC)
                  </Button>
                </div>
              </CardContent>
            </TabsContent>

            {/* Aba Editar */}
            <TabsContent value="edit">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Edit className="w-5 h-5" />
                  Editar e Marcar Artigos
                </CardTitle>
                <CardDescription>
                  Selecione uma lei, clique em um artigo e marque com cores. Títulos são formatados automaticamente.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Header com Controles */}
                <div className="mb-6 bg-gray-50 p-4 rounded-lg">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-sm font-medium">Lei Selecionada:</div>
                      <Select value={leiSelecionada?.toString() || ''} onValueChange={(value) => {
                        setLeiSelecionada(value ? Number.parseInt(value) : null)
                        setArtigoSelecionado(null)
                      }}>
                        <SelectTrigger className="w-64">
                          <SelectValue placeholder="Selecione uma lei" />
                        </SelectTrigger>
                        <SelectContent>
                          {vademecum.leis.map(lei => (
                            <SelectItem key={lei.id} value={lei.id.toString()}>
                              {lei.nome.length > 40 ? `${lei.nome.substring(0, 40)}...` : lei.nome}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {leiSelecionada && (
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => {
                          setVademecum(prev => ({
                            ...prev,
                            leis: prev.leis.filter(lei => lei.id !== leiSelecionada)
                          }))
                          setLeiSelecionada(null)
                          setArtigoSelecionado(null)
                          showMessage('success', 'Lei excluída com sucesso')
                        }}
                      >
                        <X className="w-4 h-4 mr-2" />
                        Excluir Lei
                      </Button>
                    )}
                  </div>

                  {/* Palette de Cores - Aparece quando artigo selecionado */}
                  {artigoSelecionado && (
                    <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                      <div className="flex items-center justify-between mb-3">
                        <div className="text-sm font-medium text-blue-800">
                          🎨 Marcar Artigo Selecionado
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setArtigoSelecionado(null)}
                          className="h-6 w-6 p-0 text-blue-600"
                        >
                          <X className="w-4 h-4" />
                        </Button>
                      </div>
                      <div className="grid grid-cols-6 gap-2">
                        {Object.entries(CORES).map(([cor, config]) => (
                          <Button
                            key={cor}
                            onClick={() => marcarArtigo(cor)}
                            className={`${config.bg} hover:opacity-80 text-white text-xs h-8`}
                            title={config.label}
                          >
                            {config.label}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 h-[600px]">
                  {/* Coluna Esquerda - Artigos */}
                  <Card className="h-full">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base">Artigos</CardTitle>
                      {leiAtual && (
                        <CardDescription>
                          {leiAtual.artigos.length} artigos • {leiAtual.artigos.filter(a => a.marcado).length} marcados
                        </CardDescription>
                      )}
                    </CardHeader>
                    <CardContent className="h-[520px] overflow-y-auto">
                      {!leiAtual ? (
                        <div className="flex flex-col items-center justify-center h-full text-gray-500">
                          <FileText className="w-12 h-12 mb-4 opacity-50" />
                          <p className="text-sm">Selecione uma lei para ver os artigos</p>
                        </div>
                      ) : (
                        <div className="space-y-3">
                          {leiAtual.artigos.map(artigo => (
                            <div
                              key={artigo.id}
                              onClick={() => setArtigoSelecionado(artigo.id)}
                              className={`p-4 border rounded-lg cursor-pointer hover:bg-gray-50 transition-all ${
                                artigoSelecionado === artigo.id ? 'bg-blue-50 border-blue-500 shadow-md' : ''
                              } ${
                                artigo.marcado && artigo.cor ? `border-l-4 border-l-${artigo.cor}-500` : ''
                              }`}
                            >
                              <div className="flex items-center justify-between mb-2">
                                <div className="font-medium text-sm">Art. {artigo.numeroTexto || artigo.numero}</div>
                                <div className="flex items-center gap-2">
                                  {artigo.marcado && artigo.cor && (
                                    <Badge className={`${CORES[artigo.cor as keyof typeof CORES]?.bg} text-white text-xs`}>
                                      {CORES[artigo.cor as keyof typeof CORES]?.label}
                                    </Badge>
                                  )}
                                  {detectarTitulos(artigo.texto) && (
                                    <Badge variant="outline" className="text-xs">
                                      {detectarTitulos(artigo.texto)?.length} título(s)
                                    </Badge>
                                  )}
                                  {artigoSelecionado === artigo.id && (
                                    <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse" />
                                  )}
                                </div>
                              </div>
                              <div className="text-xs text-gray-600 line-clamp-3">
                                {artigo.texto.substring(0, 200)}...
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </CardContent>
                  </Card>

                  {/* Coluna Direita - Preview Editável */}
                  <Card className="h-full">
                    <CardHeader className="pb-3">
                      <CardTitle className="text-base flex items-center justify-between">
                        <span>Preview Editável</span>
                        {artigoSelecionado && (
                          <div className="flex items-center gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={salvarTextoEditado}
                              className="text-xs"
                            >
                              Salvar Edição
                            </Button>
                            <Button
                              size="sm"
                              onClick={mostrarPaletaCores}
                              className="text-xs bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600"
                            >
                              🎨 Marcar
                            </Button>
                          </div>
                        )}
                      </CardTitle>
                      <CardDescription>
                        Edite o texto e marque com cores. Títulos são formatados automaticamente.
                      </CardDescription>
                    </CardHeader>
                    <CardContent className="h-[520px] overflow-y-auto">
                      {leiAtual && artigoSelecionado ? (
                        <div className={`p-4 border-l-4 rounded-lg ${
                          artigoAtual?.marcado && artigoAtual?.cor
                            ? `border-l-${artigoAtual.cor}-500 bg-${artigoAtual.cor}-50`
                            : 'border-l-gray-300 bg-gray-50'
                        }`}>
                          <div className="flex items-center justify-between mb-3">
                            <div className="font-semibold text-base text-blue-600">
                              Art. {artigoAtual?.numeroTexto || artigoAtual?.numero}
                            </div>
                            {artigoAtual?.marcado && artigoAtual?.cor && (
                              <div className={`w-4 h-4 rounded-full ${CORES[artigoAtual.cor as keyof typeof CORES]?.bg}`} />
                            )}
                          </div>

                          <div className="mb-4">
                            <Textarea
                              value={textoEditavel}
                              onChange={(e) => setTextoEditavel(e.target.value)}
                              className="min-h-[200px] text-sm leading-relaxed resize-none border-0 p-0 focus:ring-0 bg-transparent"
                              placeholder="Edite o texto do artigo aqui..."
                            />
                          </div>

                          {/* Preview dos títulos formatados */}
                          {formatacaoTitulosAtiva && textoEditavel && (
                            <div className="mt-4 pt-4 border-t border-gray-200">
                              <div className="text-xs font-medium text-gray-600 mb-2">
                                📖 Preview com Formatação de Títulos:
                              </div>
                              <div className="bg-white p-3 rounded border text-sm">
                                {renderTextoComTitulos(textoEditavel)}
                              </div>
                            </div>
                          )}

                          {artigoAtual?.marcado && artigoAtual?.cor && (
                            <div className="mt-3 pt-3 border-t border-gray-200">
                              <Badge className={`${CORES[artigoAtual.cor as keyof typeof CORES]?.bg} text-white`}>
                                📌 {CORES[artigoAtual.cor as keyof typeof CORES]?.label}
                              </Badge>
                            </div>
                          )}
                        </div>
                      ) : (
                        <div className="flex flex-col items-center justify-center h-full text-gray-500">
                          <Edit className="w-12 h-12 mb-4 opacity-50" />
                          <p className="text-sm">Selecione um artigo para editar</p>
                          <p className="text-xs mt-2 text-center">
                            Você poderá editar o texto, marcar com cores e ver títulos formatados
                          </p>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </TabsContent>

            {/* Aba Buscar */}
            <TabsContent value="search">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Search className="w-5 h-5" />
                  Busca Avançada
                </CardTitle>
                <CardDescription>
                  Busque por texto, número de artigos ou use filtros avançados. Busca também em títulos detectados.
                </CardDescription>
              </CardHeader>
              <CardContent>
                {/* Barra de busca principal */}
                <div className="space-y-4">
                  <div className="relative">
                    <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      placeholder="Digite sua busca... (ex: artigo 5, consumidor, etc.)"
                      value={termoBusca}
                      onChange={(e) => {
                        setTermoBusca(e.target.value)
                        realizarBusca(e.target.value)
                      }}
                      className="pl-10"
                    />
                  </div>

                  {/* Filtros avançados */}
                  <div className="flex items-center gap-2">
                    <Button
                      variant={buscaAvancada ? "default" : "outline"}
                      size="sm"
                      onClick={() => setBuscaAvancada(!buscaAvancada)}
                    >
                      <Filter className="w-4 h-4 mr-2" />
                      Filtros
                    </Button>

                    {(filtroLei || filtroCor || filtroMarcados !== 'todos') && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setFiltroLei(null)
                          setFiltroCor(null)
                          setFiltroMarcados('todos')
                          realizarBusca(termoBusca)
                        }}
                      >
                        <X className="w-4 h-4 mr-2" />
                        Limpar Filtros
                      </Button>
                    )}
                  </div>

                  {/* Painel de filtros avançados */}
                  {buscaAvancada && (
                    <Card className="p-4 bg-blue-50">
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Lei Específica</label>
                          <Select
                            value={filtroLei?.toString() || ''}
                            onValueChange={(value) => {
                              setFiltroLei(value ? Number.parseInt(value) : null)
                              realizarBusca(termoBusca)
                            }}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Todas as leis" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="">Todas as leis</SelectItem>
                              {vademecum.leis.map(lei => (
                                <SelectItem key={lei.id} value={lei.id.toString()}>
                                  {lei.nome.length > 30 ? `${lei.nome.substring(0, 30)}...` : lei.nome}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Status de Marcação</label>
                          <Select
                            value={filtroMarcados}
                            onValueChange={(value: 'todos' | 'marcados' | 'nao-marcados') => {
                              setFiltroMarcados(value)
                              realizarBusca(termoBusca)
                            }}
                          >
                            <SelectTrigger>
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="todos">Todos os artigos</SelectItem>
                              <SelectItem value="marcados">Apenas marcados</SelectItem>
                              <SelectItem value="nao-marcados">Apenas não marcados</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Cor Específica</label>
                          <Select
                            value={filtroCor || ''}
                            onValueChange={(value) => {
                              setFiltroCor(value || null)
                              realizarBusca(termoBusca)
                            }}
                          >
                            <SelectTrigger>
                              <SelectValue placeholder="Todas as cores" />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="">Todas as cores</SelectItem>
                              {Object.entries(CORES).map(([cor, config]) => (
                                <SelectItem key={cor} value={cor}>
                                  <div className="flex items-center gap-2">
                                    <div className={`w-3 h-3 rounded-full ${config.bg}`} />
                                    {config.label}
                                  </div>
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </Card>
                  )}

                  {/* Histórico de buscas */}
                  {historicoBusca.length > 0 && !termoBusca && (
                    <div>
                      <label className="block text-sm font-medium mb-2">Buscas Recentes</label>
                      <div className="flex flex-wrap gap-2">
                        {historicoBusca.map((termo) => (
                          <Button
                            key={termo}
                            variant="outline"
                            size="sm"
                            onClick={() => {
                              setTermoBusca(termo)
                              realizarBusca(termo)
                            }}
                            className="text-xs"
                          >
                            {termo}
                          </Button>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                {/* Resultados da busca */}
                <div className="mt-6">
                  {termoBusca && (
                    <div className="mb-4">
                      <div className="flex items-center justify-between">
                        <h3 className="text-lg font-semibold">
                          Resultados para "{termoBusca}"
                        </h3>
                        <Badge variant="outline">
                          {resultadosBusca.length} resultado(s)
                        </Badge>
                      </div>
                    </div>
                  )}

                  {resultadosBusca.length > 0 ? (
                    <div className="space-y-4 max-h-96 overflow-y-auto">
                      {resultadosBusca
                        .sort((a, b) => {
                          if (tipoOrdenacao === 'relevancia') return b.score - a.score
                          if (tipoOrdenacao === 'numero') return a.artigo.numero - b.artigo.numero
                          return a.lei.nome.localeCompare(b.lei.nome)
                        })
                        .map((resultado, index) => (
                          <Card key={`${resultado.artigo.id}-${index}`} className="p-4 hover:shadow-md transition-shadow">
                            <div className="flex items-start justify-between mb-2">
                              <div>
                                <h4 className="font-medium text-blue-600">
                                  Art. {resultado.artigo.numeroTexto} - {resultado.lei.nome}
                                </h4>
                                <div className="flex items-center gap-2 mt-1">
                                  <Badge variant="outline" className="text-xs">
                                    Score: {resultado.score}
                                  </Badge>
                                  {resultado.artigo.marcado && resultado.artigo.cor && (
                                    <Badge className={`${CORES[resultado.artigo.cor as keyof typeof CORES]?.bg} text-white text-xs`}>
                                      {CORES[resultado.artigo.cor as keyof typeof CORES]?.label}
                                    </Badge>
                                  )}
                                </div>
                              </div>
                              <Button
                                size="sm"
                                variant="outline"
                                onClick={() => {
                                  setLeiSelecionada(resultado.lei.id)
                                  setArtigoSelecionado(resultado.artigo.id)
                                }}
                              >
                                Editar
                              </Button>
                            </div>
                            <div className="text-sm text-gray-600 leading-relaxed">
                              {resultado.destaque.replace(/<[^>]*>/g, "")}
                            </div>
                          </Card>
                        ))}
                    </div>
                  ) : termoBusca ? (
                    <div className="text-center py-8 text-gray-500">
                      <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>Nenhum resultado encontrado para "{termoBusca}"</p>
                      <p className="text-xs mt-2">Tente usar termos diferentes ou ajustar os filtros</p>
                    </div>
                  ) : (
                    <div className="text-center py-8 text-gray-500">
                      <Search className="w-12 h-12 mx-auto mb-4 opacity-50" />
                      <p>Digite algo para começar a buscar</p>
                      <p className="text-xs mt-2">Busque por texto, número de artigos ou use filtros avançados</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </TabsContent>

            {/* Aba Cores */}
            <TabsContent value="colors">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Palette className="w-5 h-5" />
                  Sistema de Cores
                </CardTitle>
                <CardDescription>
                  Configure as cores de marcação e veja estatísticas de uso. Personalize a legenda conforme sua necessidade.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Coluna Esquerda - Configuração de Cores */}
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Legenda Personalizada</CardTitle>
                        <CardDescription>
                          Configure o significado de cada cor conforme sua metodologia de estudo
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        {Object.entries(CORES).map(([cor, config]) => (
                          <div key={cor} className="flex items-center gap-3">
                            <div className={`w-6 h-6 rounded-full ${config.bg} border-2 border-white shadow-sm`} />
                            <div className="flex-1">
                              <Input
                                placeholder={`Descrição para ${config.label}...`}
                                value={vademecum.legendaCores[cor] || ''}
                                onChange={(e) => {
                                  setVademecum(prev => ({
                                    ...prev,
                                    legendaCores: {
                                      ...prev.legendaCores,
                                      [cor]: e.target.value
                                    }
                                  }))
                                }}
                                className="text-sm"
                              />
                            </div>
                          </div>
                        ))}
                      </CardContent>
                    </Card>

                    {/* Presets de Legenda */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Presets de Legenda</CardTitle>
                        <CardDescription>
                          Aplicar configurações pré-definidas para diferentes contextos
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-3">
                          <Button
                            variant="outline"
                            className="w-full justify-start"
                            onClick={() => {
                              setVademecum(prev => ({
                                ...prev,
                                legendaCores: {
                                  verde: 'Artigos mais cobrados',
                                  azul: 'Jurisprudência relevante',
                                  amarelo: 'Alterações recentes',
                                  laranja: 'Doutrina importante',
                                  roxo: 'Súmulas vinculantes',
                                  cinza: 'Observações gerais'
                                }
                              }))
                            }}
                          >
                            📚 Concursos Públicos
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start"
                            onClick={() => {
                              setVademecum(prev => ({
                                ...prev,
                                legendaCores: {
                                  verde: 'Procedimentos essenciais',
                                  azul: 'Prazos importantes',
                                  amarelo: 'Atenção especial',
                                  laranja: 'Casos práticos',
                                  roxo: 'Jurisprudência aplicada',
                                  cinza: 'Referências complementares'
                                }
                              }))
                            }}
                          >
                            ⚖️ Prática Jurídica
                          </Button>
                          <Button
                            variant="outline"
                            className="w-full justify-start"
                            onClick={() => {
                              setVademecum(prev => ({
                                ...prev,
                                legendaCores: {
                                  verde: 'Conceitos fundamentais',
                                  azul: 'Teoria principal',
                                  amarelo: 'Exemplos práticos',
                                  laranja: 'Críticas doutrinárias',
                                  roxo: 'Evolução histórica',
                                  cinza: 'Notas complementares'
                                }
                              }))
                            }}
                          >
                            🎓 Acadêmico
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Coluna Direita - Estatísticas e Preview */}
                  <div className="space-y-6">
                    {/* Estatísticas de Uso */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Estatísticas de Uso</CardTitle>
                        <CardDescription>
                          Veja como suas marcações estão distribuídas
                        </CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-4">
                          {Object.entries(CORES).map(([cor, config]) => {
                            const quantidade = vademecum.leis.reduce((sum, lei) =>
                              sum + lei.artigos.filter(a => a.marcado && a.cor === cor).length, 0)
                            const total = stats.totalMarcados
                            const porcentagem = total > 0 ? (quantidade / total) * 100 : 0

                            return (
                              <div key={cor} className="space-y-2">
                                <div className="flex items-center justify-between text-sm">
                                  <div className="flex items-center gap-2">
                                    <div className={`w-4 h-4 rounded-full ${config.bg}`} />
                                    <span className="font-medium">{config.label}</span>
                                  </div>
                                  <span className="text-gray-600">
                                    {quantidade} ({porcentagem.toFixed(1)}%)
                                  </span>
                                </div>
                                <div className="w-full bg-gray-200 rounded-full h-2">
                                  <div
                                    className={`h-2 rounded-full ${config.bg}`}
                                    style={{ width: `${porcentagem}%` }}
                                  />
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      </CardContent>
                    </Card>

                    {/* Resumo Geral */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Resumo Geral</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-2 gap-4 text-center">
                          <div className="p-3 bg-blue-50 rounded-lg">
                            <div className="text-2xl font-bold text-blue-600">{stats.totalArtigos}</div>
                            <div className="text-xs text-blue-600">Total de Artigos</div>
                          </div>
                          <div className="p-3 bg-green-50 rounded-lg">
                            <div className="text-2xl font-bold text-green-600">{stats.totalMarcados}</div>
                            <div className="text-xs text-green-600">Artigos Marcados</div>
                          </div>
                          <div className="p-3 bg-purple-50 rounded-lg">
                            <div className="text-2xl font-bold text-purple-600">{stats.totalLeis}</div>
                            <div className="text-xs text-purple-600">Total de Leis</div>
                          </div>
                          <div className="p-3 bg-orange-50 rounded-lg">
                            <div className="text-2xl font-bold text-orange-600">{stats.coresUsadas}</div>
                            <div className="text-xs text-orange-600">Cores Utilizadas</div>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </TabsContent>

            {/* Aba Preview */}
            <TabsContent value="preview">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Eye className="w-5 h-5" />
                  Preview do Vademecum
                </CardTitle>
                <CardDescription>
                  Visualize como ficará seu vademecum com formatação de títulos e marcações coloridas.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {/* Header com estatísticas */}
                  <div className="bg-gradient-to-r from-blue-50 to-purple-50 p-6 rounded-lg border">
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-blue-600">{stats.totalLeis}</div>
                        <div className="text-sm text-gray-600">Leis</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-green-600">{stats.totalArtigos}</div>
                        <div className="text-sm text-gray-600">Artigos</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-purple-600">{stats.totalMarcados}</div>
                        <div className="text-sm text-gray-600">Marcados</div>
                      </div>
                      <div>
                        <div className="text-2xl font-bold text-orange-600">{stats.coresUsadas}</div>
                        <div className="text-sm text-gray-600">Cores</div>
                      </div>
                    </div>
                  </div>

                  {/* Preview das Leis */}
                  <div className="space-y-8">
                    {vademecum.leis.map(lei => (
                      <Card key={lei.id}>
                        <CardHeader className="bg-blue-50">
                          <CardTitle className="text-lg text-blue-800">{lei.nome}</CardTitle>
                          <CardDescription>
                            {lei.artigos.length} artigos • {lei.artigos.filter(a => a.marcado).length} marcados
                            {formatacaoTitulosAtiva && (
                              <span className="ml-2">
                                • {lei.artigos.filter(a => detectarTitulos(a.texto)).length} com títulos
                              </span>
                            )}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="max-h-96 overflow-y-auto">
                          <div className="space-y-4 mt-4">
                            {lei.artigos
                              .sort((a, b) => a.numero - b.numero)
                              .map(artigo => (
                                <div
                                  key={artigo.id}
                                  className={`p-4 rounded-lg border-l-4 ${
                                    artigo.marcado && artigo.cor
                                      ? `border-l-${artigo.cor}-500 bg-${artigo.cor}-50`
                                      : 'border-l-gray-300 bg-gray-50'
                                  }`}
                                >
                                  <div className="flex items-center justify-between mb-2">
                                    <h4 className="font-semibold text-blue-600">
                                      Art. {artigo.numeroTexto}
                                    </h4>
                                    <div className="flex items-center gap-2">
                                      {artigo.marcado && artigo.cor && (
                                        <div className={`w-3 h-3 rounded-full ${CORES[artigo.cor as keyof typeof CORES]?.bg}`} />
                                      )}
                                      {detectarTitulos(artigo.texto) && (
                                        <Badge variant="outline" className="text-xs">
                                          {detectarTitulos(artigo.texto)?.length} título(s)
                                        </Badge>
                                      )}
                                    </div>
                                  </div>

                                  {/* Renderizar texto com formatação de títulos */}
                                  <div className="text-sm leading-relaxed">
                                    {renderTextoComTitulos(artigo.texto)}
                                  </div>

                                  {artigo.marcado && artigo.cor && (
                                    <div className="mt-3 pt-3 border-t border-gray-200">
                                      <Badge className={`${CORES[artigo.cor as keyof typeof CORES]?.bg} text-white text-xs`}>
                                        📌 {CORES[artigo.cor as keyof typeof CORES]?.label}
                                      </Badge>
                                    </div>
                                  )}
                                </div>
                              ))}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {/* Legenda de Cores */}
                  {stats.totalMarcados > 0 && (
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Legenda de Cores</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                          {Object.entries(CORES).map(([cor, config]) => {
                            const quantidade = vademecum.leis.reduce((sum, lei) =>
                              sum + lei.artigos.filter(a => a.marcado && a.cor === cor).length, 0)

                            if (quantidade === 0) return null

                            return (
                              <div key={cor} className="flex items-center gap-3 text-sm">
                                <div className={`w-4 h-4 rounded-full ${config.bg}`} />
                                <span className="font-medium">{config.label}:</span>
                                <span className="text-gray-600 flex-1">
                                  {vademecum.legendaCores[cor] || 'Sem descrição'}
                                </span>
                                <Badge variant="outline" className="text-xs">
                                  {quantidade}
                                </Badge>
                              </div>
                            )
                          })}
                        </div>
                      </CardContent>
                    </Card>
                  )}
                </div>
              </CardContent>
            </TabsContent>

            {/* Aba Exportar */}
            <TabsContent value="export">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Download className="w-5 h-5" />
                  Exportar Vademecum
                </CardTitle>
                <CardDescription>
                  Configure as informações do documento e exporte para PDF ou DOCX com formatação profissional.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Coluna Esquerda - Configurações do Documento */}
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Informações do Documento</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Título do Vademecum</label>
                          <Input
                            value={tituloVademecum}
                            onChange={(e) => setTituloVademecum(e.target.value)}
                            placeholder="Ex: Vademecum Estatístico"
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Nome do Concurso/Área</label>
                          <Input
                            value={nomeConcurso}
                            onChange={(e) => setNomeConcurso(e.target.value)}
                            placeholder="Ex: Concurso TRT, Advocacia Trabalhista..."
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-sm font-medium mb-1">Autor</label>
                            <Input
                              value={autorVademecum}
                              onChange={(e) => setAutorVademecum(e.target.value)}
                              placeholder="Seu nome"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-1">Empresa/Editora</label>
                            <Input
                              value={nomeEmpresa}
                              onChange={(e) => setNomeEmpresa(e.target.value)}
                              placeholder="Nome da empresa"
                            />
                          </div>
                        </div>

                        <div className="grid grid-cols-2 gap-3">
                          <div>
                            <label className="block text-sm font-medium mb-1">Edição</label>
                            <Input
                              value={edicaoVademecum}
                              onChange={(e) => setEdicaoVademecum(e.target.value)}
                              placeholder="Ex: 1ª Edição"
                            />
                          </div>
                          <div>
                            <label className="block text-sm font-medium mb-1">Ano</label>
                            <Input
                              value={anoVademecum}
                              onChange={(e) => setAnoVademecum(e.target.value)}
                              placeholder="2024"
                            />
                          </div>
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Código/ISBN (opcional)</label>
                          <Input
                            value={codigoVademecum}
                            onChange={(e) => setCodigoVademecum(e.target.value)}
                            placeholder="Ex: ISBN 978-85-123456-7-8"
                          />
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Coluna Direita - Avisos, Comentários e Botões de Export */}
                  <div className="space-y-6">
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Avisos e Comentários</CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <div>
                          <label className="block text-sm font-medium mb-1">Avisos Importantes</label>
                          <Textarea
                            rows={3}
                            value={avisosVademecum}
                            onChange={(e) => setAvisosVademecum(e.target.value)}
                            placeholder="Avisos importantes sobre o uso do vademecum..."
                          />
                        </div>

                        <div>
                          <label className="block text-sm font-medium mb-1">Comentários Gerais</label>
                          <Textarea
                            rows={4}
                            value={comentariosVademecum}
                            onChange={(e) => setComentariosVademecum(e.target.value)}
                            placeholder="Comentários sobre metodologia, fontes, etc..."
                          />
                        </div>
                      </CardContent>
                    </Card>

                    {/* Botões de Exportação */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="text-base">Exportar Documento</CardTitle>
                        <CardDescription>
                          Gere seu vademecum em formato profissional
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="space-y-4">
                        <Button
                          onClick={gerarPDF}
                          disabled={gerandoPDF || stats.totalArtigos === 0}
                          className="w-full"
                          size="lg"
                        >
                          {gerandoPDF ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Gerando PDF...
                            </>
                          ) : (
                            <>
                              <FileText className="w-4 h-4 mr-2" />
                              Exportar para PDF
                            </>
                          )}
                        </Button>

                        <Button
                          onClick={gerarDOCX}
                          disabled={gerandoDOCX || stats.totalArtigos === 0}
                          variant="outline"
                          className="w-full"
                          size="lg"
                        >
                          {gerandoDOCX ? (
                            <>
                              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                              Gerando DOCX...
                            </>
                          ) : (
                            <>
                              <FileText className="w-4 h-4 mr-2" />
                              Exportar para DOCX
                            </>
                          )}
                        </Button>

                        {stats.totalArtigos === 0 && (
                          <p className="text-xs text-gray-500 text-center">
                            Adicione pelo menos uma lei para poder exportar
                          </p>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </div>
              </CardContent>
            </TabsContent>
          </Tabs>
        </Card>

        {/* Paleta de cores flutuante */}
        {mostrarCoresFlutantes && (
          <div
            className="fixed z-50 bg-white border rounded-lg shadow-lg p-3"
            style={{
              left: `${posicaoCores.x}px`,
              top: `${posicaoCores.y}px`
            }}
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs font-medium">Marcar com cor:</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMostrarCoresFlutantes(false)}
                className="h-4 w-4 p-0"
              >
                <X className="h-3 w-3" />
              </Button>
            </div>
            <div className="grid grid-cols-3 gap-2">
              {Object.entries(CORES).map(([cor, config]) => (
                <Button
                  key={cor}
                  onClick={() => marcarArtigo(cor)}
                  className={`${config.bg} hover:opacity-80 text-white text-xs h-8 w-full`}
                  title={config.label}
                >
                  {config.label}
                </Button>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default App
