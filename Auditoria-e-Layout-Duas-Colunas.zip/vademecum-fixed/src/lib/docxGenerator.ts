import { Document, Packer, Paragraph, TextRun, HeadingLevel, Table, TableCell, TableRow, WidthType, BorderStyle, AlignmentType, PageBreak, PageOrientation } from 'docx'
import { saveAs } from 'file-saver'

// Tipos para o gerador de DOCX
interface ArtigoDOCX {
  id: number
  numero: number
  numeroTexto: string
  texto: string
  marcado: boolean
  cor: string | null
  nomeFromLei: string
  titulos?: { texto: string; posicao: number }[]
}

interface LeiDOCX {
  nome: string
  artigos: ArtigoDOCX[]
}

interface ConfigDOCX {
  titulo: string
  concurso: string
  autor?: string
  codigo?: string
  empresa?: string
  edicao?: string
  ano?: string
  avisos?: string
  comentarios?: string
  tituloTransicao?: string
  subtituloTransicao?: string
  legendaCores: Record<string, string>
  formatacaoTitulosAtiva: boolean
  delimitadorInicial: string
  delimitadorFinal: string
}

// Configurações de cores para DOCX
const CORES_DOCX = {
  verde: '22C55E',
  azul: '3B82F6',
  amarelo: 'EAB308',
  laranja: 'F97316',
  roxo: '8B5CF6',
  cinza: '6B7280'
}

export class VademecumDOCXGenerator {

  public async gerarDOCX(leis: LeiDOCX[], config: ConfigDOCX): Promise<void> {
    // Construir documento com todas as seções
    const children = [
      ...this.gerarCapa(config),
      ...this.gerarPaginaEstatisticas(leis, config.legendaCores),
      ...this.gerarPaginaInformacoes(config),
      ...this.gerarLegendaCores(config.legendaCores),
      ...this.gerarSumario(leis),
      ...this.gerarPaginaTransicao(config),
      ...this.gerarConteudoCompleto(leis, config)
    ]

    const doc = new Document({
      sections: [
        {
          properties: {
            page: {
              margin: {
                top: 720,    // 0.5 inch
                right: 720,  // 0.5 inch
                bottom: 720, // 0.5 inch
                left: 720    // 0.5 inch
              },
              size: {
                orientation: PageOrientation.PORTRAIT
              }
            }
          },
          children: children
        }
      ]
    })

    // Gerar e baixar arquivo
    const blob = await Packer.toBlob(doc)
    const nomeArquivo = `${config.titulo.replace(/[^a-zA-Z0-9]/g, '-')}.docx`
    saveAs(blob, nomeArquivo)
  }

  private gerarCapa(config: ConfigDOCX): Paragraph[] {
    const elementos: Paragraph[] = []

    // Título principal
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: config.titulo.toUpperCase(),
            bold: true,
            size: 32,
            color: '1F2937'
          })
        ],
        heading: HeadingLevel.TITLE,
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 }
      })
    )

    // Concurso (se fornecido)
    if (config.concurso) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: config.concurso,
              size: 24,
              color: '3B82F6'
            })
          ],
          alignment: AlignmentType.CENTER,
          spacing: { after: 300 }
        })
      )
    }

    // Subtítulo
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: 'Compilação Jurídica com Marcação Inteligente',
            size: 18,
            color: '6B7280'
          })
        ],
        alignment: AlignmentType.CENTER,
        spacing: { after: 600 }
      })
    )

    // Informações do autor e empresa
    if (config.autor) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `Autor: ${config.autor}`,
              bold: true,
              size: 20
            })
          ],
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 }
        })
      )
    }

    if (config.empresa) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: config.empresa,
              size: 16,
              color: '6B7280'
            })
          ],
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 }
        })
      )
    }

    // Edição e Ano
    if (config.edicao || config.ano) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `${config.edicao || ''} ${config.ano || ''}`.trim(),
              size: 14,
              color: '6B7280'
            })
          ],
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 }
        })
      )
    }

    // Código/ISBN
    if (config.codigo) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `Código: ${config.codigo}`,
              size: 12,
              color: '6B7280'
            })
          ],
          alignment: AlignmentType.CENTER,
          spacing: { after: 200 }
        })
      )
    }

    // Data de geração
    const dataAtual = new Date().toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    })

    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: `Gerado em ${dataAtual}`,
            size: 14,
            color: '6B7280'
          })
        ],
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 }
      })
    )

    // Avisos importantes
    if (config.avisos) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: '⚠️ AVISO IMPORTANTE:',
              bold: true,
              size: 12,
              color: 'D97706'
            })
          ],
          spacing: { after: 100 }
        }),
        new Paragraph({
          children: [
            new TextRun({
              text: config.avisos,
              size: 11,
              color: '374151'
            })
          ],
          spacing: { after: 400 }
        })
      )
    }

    // Rodapé da capa
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: 'IA Team © 2024 • Vade Mecum Estatístico v2.0',
            size: 10,
            color: '9CA3AF'
          })
        ],
        alignment: AlignmentType.CENTER
      })
    )

    // Quebra de página
    elementos.push(new Paragraph({ children: [new PageBreak()] }))

    return elementos
  }

  private gerarPaginaEstatisticas(leis: LeiDOCX[], legendaCores: Record<string, string>): Paragraph[] {
    const elementos: Paragraph[] = []

    // Título da página
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: 'ESTATÍSTICAS DE MARCAÇÃO',
            bold: true,
            size: 28,
            color: '1F2937'
          })
        ],
        heading: HeadingLevel.HEADING_1,
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 }
      })
    )

    // Calcular estatísticas
    const totalArtigos = leis.reduce((sum, lei) => sum + lei.artigos.length, 0)
    const artigosMarcados = leis.reduce((sum, lei) => sum + lei.artigos.filter(a => a.marcado).length, 0)

    // Estatísticas gerais
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: `Total de Artigos: ${totalArtigos}`,
            bold: true,
            size: 16,
            color: '1F2937'
          })
        ],
        spacing: { after: 200 }
      }),
      new Paragraph({
        children: [
          new TextRun({
            text: `Artigos Marcados: ${artigosMarcados}`,
            bold: true,
            size: 16,
            color: '3B82F6'
          })
        ],
        spacing: { after: 400 }
      })
    )

    // Título das estatísticas por cor
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: 'DISTRIBUIÇÃO POR CATEGORIA',
            bold: true,
            size: 18,
            color: '1F2937'
          })
        ],
        spacing: { after: 300 }
      })
    )

    // Estatísticas por cor
    const cores = ['verde', 'azul', 'amarelo', 'laranja', 'roxo', 'cinza']
    for (const cor of cores) {
      const quantidade = leis.reduce((sum, lei) =>
        sum + lei.artigos.filter(a => a.marcado && a.cor === cor).length, 0)
      const porcentagem = artigosMarcados > 0 ? (quantidade / artigosMarcados) * 100 : 0

      if (quantidade > 0) {
        elementos.push(
          new Paragraph({
            children: [
              new TextRun({
                text: '● ',
                color: CORES_DOCX[cor as keyof typeof CORES_DOCX],
                size: 16,
                bold: true
              }),
              new TextRun({
                text: `${legendaCores[cor] || cor}: `,
                bold: true,
                size: 12
              }),
              new TextRun({
                text: `${quantidade} artigos (${porcentagem.toFixed(1)}%)`,
                size: 12
              })
            ],
            spacing: { after: 150 }
          })
        )
      }
    }

    // Quebra de página
    elementos.push(new Paragraph({ children: [new PageBreak()] }))

    return elementos
  }

  private gerarPaginaInformacoes(config: ConfigDOCX): Paragraph[] {
    const elementos: Paragraph[] = []

    if (!config.avisos && !config.comentarios) {
      return elementos
    }

    // Título da página
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: 'INFORMAÇÕES IMPORTANTES',
            bold: true,
            size: 28,
            color: '1F2937'
          })
        ],
        heading: HeadingLevel.HEADING_1,
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 }
      })
    )

    // Seção de Avisos
    if (config.avisos) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: '⚠️ AVISOS IMPORTANTES',
              bold: true,
              size: 16,
              color: 'DC2626'
            })
          ],
          spacing: { after: 200 }
        }),
        new Paragraph({
          children: [
            new TextRun({
              text: config.avisos,
              size: 12,
              color: '374151'
            })
          ],
          spacing: { after: 400 }
        })
      )
    }

    // Seção de Comentários
    if (config.comentarios) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: '💬 COMENTÁRIOS E OBSERVAÇÕES',
              bold: true,
              size: 16,
              color: '3B82F6'
            })
          ],
          spacing: { after: 200 }
        }),
        new Paragraph({
          children: [
            new TextRun({
              text: config.comentarios,
              size: 12,
              color: '374151'
            })
          ],
          spacing: { after: 400 }
        })
      )
    }

    // Informações técnicas
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: '📋 INFORMAÇÕES TÉCNICAS',
            bold: true,
            size: 14,
            color: '6B7280'
          })
        ],
        spacing: { after: 200 }
      })
    )

    const infoTecnica = [
      `• Título: ${config.titulo}`,
      `• Autor: ${config.autor || 'Não especificado'}`,
      `• Empresa/Editora: ${config.empresa || 'Não especificada'}`,
      `• Edição: ${config.edicao || 'Não especificada'}`,
      `• Ano: ${config.ano || new Date().getFullYear()}`,
      `• Código: ${config.codigo || 'Não especificado'}`,
      "• Sistema: Vademecum Editor v2.0 - IA Team",
      `• Gerado em: ${new Date().toLocaleDateString('pt-BR')} às ${new Date().toLocaleTimeString('pt-BR')}`
    ]

    for (const info of infoTecnica) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: info,
              size: 10,
              color: '6B7280'
            })
          ],
          spacing: { after: 100 }
        })
      )
    }

    // Quebra de página
    elementos.push(new Paragraph({ children: [new PageBreak()] }))

    return elementos
  }

  private gerarLegendaCores(legendaCores: Record<string, string>): Paragraph[] {
    const elementos: Paragraph[] = []

    // Título da página
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: 'SISTEMA DE CORES',
            bold: true,
            size: 28,
            color: '1F2937'
          })
        ],
        heading: HeadingLevel.HEADING_1,
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 }
      })
    )

    // Grid de cores
    const cores = ['verde', 'azul', 'amarelo', 'laranja', 'roxo', 'cinza']
    for (const cor of cores) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: '● ',
              color: CORES_DOCX[cor as keyof typeof CORES_DOCX],
              size: 20,
              bold: true
            }),
            new TextRun({
              text: cor.toUpperCase(),
              bold: true,
              size: 14,
              color: '1F2937'
            }),
            new TextRun({
              text: ` - ${legendaCores[cor] || 'Sem descrição'}`,
              size: 12,
              color: '374151'
            })
          ],
          spacing: { after: 200 }
        })
      )
    }

    // Instruções de uso
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: 'COMO USAR ESTE VADEMECUM',
            bold: true,
            size: 16,
            color: '1F2937'
          })
        ],
        spacing: { before: 400, after: 300 }
      })
    )

    const instrucoes = [
      '✓ Os artigos estão organizados por lei de origem',
      '✓ Cada cor representa um tipo de importância específica',
      '✓ Use o sumário para navegação rápida entre leis',
      '✓ Artigos marcados possuem destaque colorido',
      '✓ Títulos são formatados automaticamente quando detectados'
    ]

    for (const instrucao of instrucoes) {
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: instrucao,
              size: 11,
              color: '374151'
            })
          ],
          spacing: { after: 100 }
        })
      )
    }

    // Quebra de página
    elementos.push(new Paragraph({ children: [new PageBreak()] }))

    return elementos
  }

  private gerarSumario(leis: LeiDOCX[]): Paragraph[] {
    const elementos: Paragraph[] = []

    // Título do sumário
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: 'SUMÁRIO GERAL',
            bold: true,
            size: 28,
            color: '1F2937'
          })
        ],
        heading: HeadingLevel.HEADING_1,
        alignment: AlignmentType.CENTER,
        spacing: { after: 400 }
      })
    )

    leis.forEach((lei, index) => {
      const artigosMarcados = lei.artigos.filter(a => a.marcado).length

      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: `${index + 1}. `,
              bold: true,
              size: 12,
              color: '3B82F6'
            }),
            new TextRun({
              text: lei.nome,
              bold: true,
              size: 12,
              color: '1F2937'
            })
          ],
          spacing: { after: 100 }
        }),
        new Paragraph({
          children: [
            new TextRun({
              text: `    ${lei.artigos.length} artigos • ${artigosMarcados} marcados`,
              size: 10,
              color: '6B7280'
            })
          ],
          spacing: { after: 200 }
        })
      )
    })

    // Estatísticas totais
    const totalArtigos = leis.reduce((sum, lei) => sum + lei.artigos.length, 0)
    const totalMarcados = leis.reduce((sum, lei) => sum + lei.artigos.filter(a => a.marcado).length, 0)

    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: `Total: ${leis.length} leis • ${totalArtigos} artigos • ${totalMarcados} marcados`,
            bold: true,
            size: 12,
            color: '1F2937'
          })
        ],
        alignment: AlignmentType.CENTER,
        spacing: { before: 400 }
      })
    )

    // Quebra de página
    elementos.push(new Paragraph({ children: [new PageBreak()] }))

    return elementos
  }

  private gerarPaginaTransicao(config: ConfigDOCX): Paragraph[] {
    const elementos: Paragraph[] = []

    // Título elegante centralizado
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: config.tituloTransicao || 'LEGISLAÇÃO',
            bold: true,
            size: 36,
            color: '3B82F6'
          })
        ],
        alignment: AlignmentType.CENTER,
        spacing: { before: 2000, after: 300 }
      })
    )

    // Subtítulo
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: config.subtituloTransicao || 'Compilação de Artigos por Lei',
            size: 18,
            color: '6B7280'
          })
        ],
        alignment: AlignmentType.CENTER,
        spacing: { after: 2000 }
      })
    )

    // Quebra de página
    elementos.push(new Paragraph({ children: [new PageBreak()] }))

    return elementos
  }

  private gerarConteudoCompleto(leis: LeiDOCX[], config: ConfigDOCX): Paragraph[] {
    const elementos: Paragraph[] = []

    for (const lei of leis) {
      // Título da lei
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: lei.nome.toUpperCase(),
              bold: true,
              size: 18,
              color: '3B82F6'
            })
          ],
          heading: HeadingLevel.HEADING_1,
          spacing: { before: 400, after: 300 }
        })
      )

      // Ordenar artigos por número crescente
      const artigosOrdenados = [...lei.artigos].sort((a, b) => a.numero - b.numero)

      for (const artigo of artigosOrdenados) {
        elementos.push(...this.gerarArtigo(artigo, config))
      }

      // Espaço entre leis
      elementos.push(
        new Paragraph({
          children: [new TextRun({ text: '' })],
          spacing: { after: 600 }
        })
      )
    }

    return elementos
  }

  private gerarArtigo(artigo: ArtigoDOCX, config: ConfigDOCX): Paragraph[] {
    const elementos: Paragraph[] = []

    // Processar texto removendo número do artigo se já existir
    let textoArtigo = artigo.texto.trim()
    const regexArtigo = new RegExp(`^Art\\.?\\s*${artigo.numeroTexto}[ºª°]?[\\s\\-–—\\.]`, 'i')
    if (regexArtigo.test(textoArtigo)) {
      textoArtigo = textoArtigo.replace(regexArtigo, '').trim()
    }

    // Cor do artigo (se marcado)
    const corArtigo = artigo.marcado && artigo.cor ? CORES_DOCX[artigo.cor as keyof typeof CORES_DOCX] : '1F2937'

    // Título do artigo
    elementos.push(
      new Paragraph({
        children: [
          new TextRun({
            text: `Art. ${artigo.numeroTexto}`,
            bold: true,
            size: 14,
            color: corArtigo
          })
        ],
        spacing: { before: 200, after: 100 }
      })
    )

    // Processar texto com títulos (se ativo)
    if (config.formatacaoTitulosAtiva) {
      const elementosTexto = this.processarTextoComTitulos(textoArtigo, config, corArtigo)
      elementos.push(...elementosTexto)
    } else {
      // Texto simples sem formatação de títulos
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: textoArtigo,
              size: 12,
              color: '374151'
            })
          ],
          spacing: { after: 300 }
        })
      )
    }

    return elementos
  }

  private processarTextoComTitulos(texto: string, config: ConfigDOCX, corArtigo: string): Paragraph[] {
    const elementos: Paragraph[] = []

    try {
      const escapedInicial = config.delimitadorInicial.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      const escapedFinal = config.delimitadorFinal.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')
      const regexPattern = `${escapedInicial}(.*?)${escapedFinal}`
      const regexTitulo = new RegExp(regexPattern, 'g')

      const partes = texto.split(regexTitulo)

      for (let i = 0; i < partes.length; i++) {
        if (i % 2 === 0) {
          // Texto normal
          if (partes[i].trim()) {
            elementos.push(
              new Paragraph({
                children: [
                  new TextRun({
                    text: partes[i].trim(),
                    size: 12,
                    color: '374151'
                  })
                ],
                spacing: { after: 200 }
              })
            )
          }
        } else {
          // Título formatado
          elementos.push(
            new Paragraph({
              children: [
                new TextRun({
                  text: partes[i].trim(),
                  bold: true,
                  size: 16,
                  color: '1E40AF'
                })
              ],
              spacing: { before: 300, after: 200 }
            })
          )
        }
      }
    } catch {
      // Se houver erro no regex, renderizar texto simples
      elementos.push(
        new Paragraph({
          children: [
            new TextRun({
              text: texto,
              size: 12,
              color: '374151'
            })
          ],
          spacing: { after: 300 }
        })
      )
    }

    return elementos
  }
}
