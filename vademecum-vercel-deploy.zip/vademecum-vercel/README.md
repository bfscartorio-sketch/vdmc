# Vademecum Estatístico

Editor profissional de leis com marcação colorida e sistema de títulos.

## Funcionalidades

- 📚 **Importação de Leis**: Cole o texto completo de leis e códigos jurídicos
- 🎨 **Marcação Colorida**: Sistema de cores para destacar artigos importantes
- 🔍 **Busca Avançada**: Encontre rapidamente artigos específicos
- 📝 **Sistema de Títulos**: Formatação automática de títulos em negrito e destaque
- 📊 **Anotações**: Adicione notas pessoais aos artigos
- 🏷️ **Tags**: Organize artigos com sistema de etiquetas
- ⭐ **Importância**: Classifique artigos por nível de importância (1-5)
- 📄 **Exportação**: Gere PDFs e documentos DOCX profissionais
- 💾 **Persistência**: Dados salvos automaticamente no navegador

## Tecnologias

- **React 18** com TypeScript
- **Vite** para build rápido
- **Tailwind CSS** para estilização
- **Radix UI** para componentes acessíveis
- **Lucide React** para ícones
- **jsPDF** para geração de PDFs
- **docx** para geração de documentos Word

## Deploy no Vercel

Este projeto está configurado para deploy automático no Vercel:

1. Faça fork/clone deste repositório
2. Conecte seu GitHub ao Vercel
3. Importe este projeto no Vercel
4. Deploy automático será feito

## Desenvolvimento Local

```bash
# Instalar dependências
npm install

# Executar em desenvolvimento
npm run dev

# Build para produção
npm run build

# Preview do build
npm run preview
```

## Estrutura do Projeto

```
src/
├── components/ui/     # Componentes de interface
├── lib/              # Utilitários e geradores
├── App.tsx           # Componente principal
├── main.tsx          # Ponto de entrada
└── index.css         # Estilos globais
```

## Licença

Este projeto foi criado para uso educacional e profissional no âmbito jurídico.

