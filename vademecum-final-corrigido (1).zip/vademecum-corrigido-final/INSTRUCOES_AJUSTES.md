# 🔧 Vademecum - Versão para Ajustes

Esta é uma **cópia segura** do projeto Vademecum Estatístico para trabalhar ajustes sem afetar a versão em produção.

## 🌐 Versão em Produção (NÃO ALTERAR)
- **URL**: https://hysnxumi.manus.space
- **Localização**: `/home/ubuntu/extracted_site/vademecum-fixed/`
- **Status**: ✅ Funcionando perfeitamente

## 🛠️ Versão para Ajustes (TRABALHAR AQUI)
- **Localização**: `/home/ubuntu/vademecum-ajustes/`
- **Status**: 🔄 Pronta para modificações

## 📁 Estrutura do Projeto

```
vademecum-ajustes/
├── src/
│   ├── App.tsx              # Componente principal
│   ├── main.tsx             # Ponto de entrada
│   ├── index.css            # Estilos globais
│   ├── components/ui/       # Componentes de interface
│   └── lib/                 # Utilitários (PDF, DOCX)
├── public/                  # Arquivos estáticos
├── package.json             # Dependências
├── vite.config.ts           # Configuração do Vite
├── tailwind.config.js       # Configuração do Tailwind
└── tsconfig.json            # Configuração TypeScript
```

## 🚀 Como Trabalhar com os Ajustes

### 1. Instalar Dependências
```bash
cd /home/ubuntu/vademecum-ajustes
npm install
```

### 2. Executar em Desenvolvimento
```bash
npm run dev
```

### 3. Fazer Build para Produção
```bash
npm run build
```

### 4. Testar Localmente
```bash
npm run preview
```

## 🔄 Workflow Recomendado

1. **Fazer ajustes** nos arquivos desta pasta
2. **Testar localmente** com `npm run dev`
3. **Validar funcionamento** completo
4. **Fazer build** com `npm run build`
5. **Deploy da versão ajustada** (se aprovada)

## ⚠️ Importante

- **NUNCA** altere arquivos em `/home/ubuntu/extracted_site/vademecum-fixed/`
- **SEMPRE** trabalhe apenas nesta pasta `/home/ubuntu/vademecum-ajustes/`
- **TESTE** completamente antes de fazer deploy
- **MANTENHA** backup da versão funcionando

## 📝 Registro de Ajustes

Documente aqui os ajustes realizados:

### Ajuste 1: [Descrever]
- **Data**: 
- **Descrição**: 
- **Arquivos alterados**: 
- **Status**: 

### Ajuste 2: [Descrever]
- **Data**: 
- **Descrição**: 
- **Arquivos alterados**: 
- **Status**: 

